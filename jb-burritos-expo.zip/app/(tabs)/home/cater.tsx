import { View, Text } from 'react-native'
import React from 'react'
import CaterForm from '../../../components/CaterForm'
import Logo from '../../../components/Logo'

const cater = () => {
  return (
    <View>
      <Text>cater</Text>
      <CaterForm></CaterForm>
    </View>
  )
}

export default cater