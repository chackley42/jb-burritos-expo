import { Text, View } from 'react-native'
import React, { Component } from 'react'
import LoginScreen from '../../components/LoginScreen'

export class profile extends Component {
  render() {
    return (
      <View>
        <LoginScreen></LoginScreen>
      </View>
    )
  }
}

export default profile