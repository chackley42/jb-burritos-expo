# JB Burritos

CS 4900 Capstone 

## 🚀 How to use (run in root project folder)

```sh
npx expo start
```

## 📝 Notes

- Coming very soon
